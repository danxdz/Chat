# Whisperz - Secure P2P Chat

A clean, minimalist decentralized P2P chat application using Gun.js for data management and WebRTC for secure direct messaging.

```
╦ ╦╦ ╦╦╔═╗╔═╗╔═╗╦═╗╔═╗
║║║╠═╣║╚═╗╠═╝║╣ ╠╦╝╔═╝
╚╩╝╩ ╩╩╚═╝╩  ╚═╝╩╚═╚═╝
```

## Features

- **Decentralized Architecture** - No central server, data synced across Gun.js peers
- **End-to-End Encryption** - WebRTC direct connections with built-in encryption
- **Invite-Only Registration** - Controlled access with invite codes
- **Admin System** - Complete CRUD operations for user and invite management
- **Clean Terminal UI** - Minimalist hacker aesthetic, no flashy effects
- **Modular Design** - Easy to extend with new features

## Tech Stack

- **Gun.js** - Decentralized database with SEA (Security, Encryption, Authorization)
- **WebRTC** - Peer-to-peer secure communication via SimplePeer
- **Vite** - Fast development and build tool
- **Vanilla JavaScript** - No framework dependencies, clean modular code

## Installation

```bash
# Clone the repository
git clone https://github.com/danxdz/Whisperz.git
cd whisperz

# Install dependencies
npm install

# Start development server
npm run dev
```

The application will be available at `http://localhost:3000`

## Architecture

### Modular System

The application uses a custom module manager for clean separation of concerns:

```
src/
├── core/
│   └── ModuleManager.js    # Core module system
├── modules/
│   ├── GunModule.js        # Gun.js data management
│   ├── WebRTCModule.js     # P2P communication
│   ├── AuthModule.js       # Authentication & invites
│   └── AdminModule.js      # Admin CRUD operations
├── styles/
│   └── main.css           # Terminal-inspired styling
└── main.js                # Application entry point
```

### Key Modules

#### GunModule
- User authentication with Gun SEA
- Contact management
- Chat room functionality
- Real-time data synchronization

#### WebRTCModule
- SimplePeer integration
- Signaling through Gun.js
- Direct P2P messaging
- File transfer support

#### AuthModule
- Invite-only registration
- Session management
- Admin status verification

#### AdminModule
- User management (list, ban, details)
- Invite generation and revocation
- Friendship management
- System statistics

## Usage

### First Admin Setup

1. Start the application
2. Register with the first user (temporarily disable invite check in code)
3. Manually add admin status in Gun.js:
```javascript
gun.get('admins').get('USER_PUBLIC_KEY').put(true)
```

### Generate Invites (Admin)

1. Login as admin
2. Open admin panel
3. Go to Invites tab
4. Click "generate invite"
5. Share the code with new users

### Register New User

1. Obtain invite code from admin
2. Click "register --invite"
3. Enter invite code and credentials
4. Account created and auto-login

### Add Contacts

1. Get contact's public key
2. Click "+ add contact"
3. Enter public key and optional alias
4. Contact appears in sidebar

### Start Chatting

1. Click on a contact
2. Wait for WebRTC connection
3. Send encrypted messages directly

## Security

- **No Central Server** - Data distributed across Gun.js network
- **Encrypted Storage** - Gun SEA encrypts user data
- **Direct P2P** - Messages sent directly via WebRTC
- **Invite-Only** - Controlled access to the network

## Development

### Add New Module

1. Create module in `src/modules/`
2. Extend EventEmitter for events
3. Implement `init()` and `cleanup()` methods
4. Register in `main.js`:
```javascript
await moduleManager.register('moduleName', moduleInstance, ['dependencies']);
```

### Build for Production

```bash
npm run build
```

Files will be in `dist/` directory.

## Configuration

### Gun.js Peers

Edit default peers in `GunModule.js`:
```javascript
const peers = config.gunPeers || [
  'https://gun-manhattan.herokuapp.com/gun',
  // Add your peers here
];
```

### ICE Servers

Configure STUN/TURN servers in `WebRTCModule.js`:
```javascript
this.iceServers = [
  { urls: 'stun:stun.l.google.com:19302' },
  // Add TURN servers for better connectivity
];
```

## Contributing

1. Fork the repository
2. Create feature branch
3. Commit changes
4. Push to branch
5. Open pull request

## License

MIT License - See LICENSE file for details

## Acknowledgments

- Gun.js team for the decentralized database
- SimplePeer for WebRTC abstraction
- The cypherpunk community for inspiration

---

**Remember**: This is a tool for secure, private communication. Use responsibly.