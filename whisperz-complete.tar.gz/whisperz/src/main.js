/**
 * Whisperz Main Application
 * Clean, modular P2P chat system
 */

import moduleManager from './core/ModuleManager.js';
import gunModule from './modules/GunModule.js';
import webRTCModule from './modules/WebRTCModule.js';
import authModule from './modules/AuthModule.js';
import adminModule from './modules/AdminModule.js';

class WhisperzApp {
  constructor() {
    this.currentScreen = 'landing';
    this.currentChat = null;
    this.currentPeer = null;
    this.init();
  }

  async init() {
    console.log('[WHISPERZ] Initializing...');
    
    // Register modules
    await moduleManager.register('gun', gunModule);
    await moduleManager.register('webrtc', webRTCModule, ['gun']);
    await moduleManager.register('auth', authModule, ['gun']);
    await moduleManager.register('admin', adminModule, ['gun', 'auth']);
    
    // Initialize all modules
    await moduleManager.initializeAll();
    
    // Set up event listeners
    this.setupEventListeners();
    this.setupModuleListeners();
    
    // Check for existing session
    if (authModule.isAuthenticated()) {
      this.showMain();
    }
    
    console.log('[WHISPERZ] Ready');
  }

  setupEventListeners() {
    // Login form
    document.getElementById('loginForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const username = document.getElementById('loginUsername').value;
      const password = document.getElementById('loginPassword').value;
      
      const result = await authModule.login(username, password);
      if (result.success) {
        this.showMain();
      } else {
        document.getElementById('loginError').textContent = result.error;
      }
    });

    // Register form
    document.getElementById('registerForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const inviteCode = document.getElementById('inviteCode').value;
      const username = document.getElementById('registerUsername').value;
      const password = document.getElementById('registerPassword').value;
      
      const result = await authModule.registerWithInvite(username, password, inviteCode);
      if (result.success) {
        this.showMain();
      } else {
        document.getElementById('registerError').textContent = result.error;
      }
    });

    // Message input
    document.getElementById('messageInput').addEventListener('keypress', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        this.sendMessage();
      }
    });

    document.getElementById('sendBtn').addEventListener('click', () => {
      this.sendMessage();
    });

    // Admin tabs
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        this.switchTab(e.target.dataset.tab);
      });
    });
  }

  setupModuleListeners() {
    // Auth events
    authModule.on('auth:success', (user) => {
      document.getElementById('currentUser').textContent = `@${user.username}`;
      if (authModule.isAdmin) {
        document.querySelector('#main .sidebar #adminPanel').classList.remove('hidden');
      }
      this.loadContacts();
    });

    authModule.on('auth:logout', () => {
      this.showLanding();
    });

    // WebRTC events
    webRTCModule.on('peer:connected', ({ pubKey }) => {
      document.getElementById('connectionStatus').textContent = '[CONNECTED]';
      document.getElementById('connectionStatus').style.color = 'var(--text-primary)';
      this.enableChat();
    });

    webRTCModule.on('peer:closed', () => {
      document.getElementById('connectionStatus').textContent = '[DISCONNECTED]';
      document.getElementById('connectionStatus').style.color = 'var(--error-color)';
      this.disableChat();
    });

    webRTCModule.on('message:received', ({ from, content, timestamp }) => {
      if (from === this.currentPeer) {
        this.displayMessage(content, false, timestamp);
      }
    });

    // Gun events
    gunModule.on('user:contact:updated', ({ id, contact }) => {
      this.updateContactsList();
    });
  }

  // Navigation methods
  showLanding() {
    this.switchScreen('landing');
  }

  showLogin() {
    this.switchScreen('login');
  }

  showInvite() {
    this.switchScreen('invite');
  }

  showMain() {
    this.switchScreen('main');
    this.loadContacts();
  }

  switchScreen(screenName) {
    document.querySelectorAll('.screen').forEach(screen => {
      screen.classList.remove('active');
    });
    document.getElementById(screenName).classList.add('active');
    this.currentScreen = screenName;
  }

  // Chat methods
  async loadContacts() {
    const contacts = await gunModule.getContacts();
    const contactsList = document.getElementById('contactsList');
    contactsList.innerHTML = '';
    
    Object.entries(contacts).forEach(([pubKey, contact]) => {
      const item = document.createElement('div');
      item.className = 'contact-item';
      item.dataset.pubkey = pubKey;
      item.innerHTML = `
        <span class="contact-name">${contact.alias || pubKey.substring(0, 8)}</span>
        <span class="contact-status"></span>
      `;
      item.addEventListener('click', () => this.selectContact(pubKey, contact));
      contactsList.appendChild(item);
    });
  }

  selectContact(pubKey, contact) {
    // Update UI
    document.querySelectorAll('.contact-item').forEach(item => {
      item.classList.remove('active');
    });
    document.querySelector(`[data-pubkey="${pubKey}"]`).classList.add('active');
    
    // Set current chat
    this.currentPeer = pubKey;
    document.getElementById('chatTitle').textContent = contact.alias || pubKey.substring(0, 8);
    document.getElementById('messages').innerHTML = '';
    
    // Connect via WebRTC
    this.connectToPeer(pubKey);
  }

  async connectToPeer(pubKey) {
    document.getElementById('connectionStatus').textContent = '[CONNECTING...]';
    document.getElementById('connectionStatus').style.color = 'var(--warning-color)';
    
    webRTCModule.connectToPeer(pubKey);
  }

  enableChat() {
    document.getElementById('messageInput').disabled = false;
    document.getElementById('sendBtn').disabled = false;
  }

  disableChat() {
    document.getElementById('messageInput').disabled = true;
    document.getElementById('sendBtn').disabled = true;
  }

  sendMessage() {
    const input = document.getElementById('messageInput');
    const message = input.value.trim();
    
    if (!message || !this.currentPeer) return;
    
    // Send via WebRTC
    const sent = webRTCModule.sendChatMessage(this.currentPeer, message);
    
    if (sent) {
      this.displayMessage(message, true, Date.now());
      input.value = '';
    }
  }

  displayMessage(content, isOwn, timestamp) {
    const messagesDiv = document.getElementById('messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isOwn ? 'own' : ''}`;
    
    const time = new Date(timestamp).toLocaleTimeString();
    
    messageDiv.innerHTML = `
      <div class="message-content">${this.escapeHtml(content)}</div>
      <div class="message-time">${time}</div>
    `;
    
    messagesDiv.appendChild(messageDiv);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // Admin methods
  showAdminPanel() {
    document.getElementById('adminPanel').classList.remove('hidden');
    this.loadAdminData();
  }

  closeAdminPanel() {
    document.getElementById('adminPanel').classList.add('hidden');
  }

  switchTab(tabName) {
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.classList.remove('active');
    });
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    
    document.querySelectorAll('.tab-content').forEach(content => {
      content.classList.remove('active');
    });
    document.getElementById(`${tabName}Tab`).classList.add('active');
    
    if (tabName === 'stats') {
      this.loadStats();
    }
  }

  async loadAdminData() {
    if (!adminModule.isAdmin()) return;
    
    this.refreshUsers();
    this.refreshInvites();
  }

  async refreshUsers() {
    const users = await adminModule.listUsers();
    const usersList = document.getElementById('usersList');
    usersList.innerHTML = '';
    
    users.forEach(user => {
      const item = document.createElement('div');
      item.className = 'admin-list-item';
      item.innerHTML = `
        <div class="item-info">
          <div>@${user.alias}</div>
          <div style="font-size: 10px; color: var(--text-dim);">${user.pub.substring(0, 16)}...</div>
        </div>
        <div class="item-actions">
          <button class="terminal-btn small" onclick="admin.banUser('${user.pub}')">ban</button>
        </div>
      `;
      usersList.appendChild(item);
    });
  }

  async refreshInvites() {
    const invites = await adminModule.listInvites();
    const invitesList = document.getElementById('invitesList');
    invitesList.innerHTML = '';
    
    invites.forEach(invite => {
      const item = document.createElement('div');
      item.className = 'admin-list-item';
      const status = invite.used ? 'USED' : 'ACTIVE';
      const statusColor = invite.used ? 'var(--text-dim)' : 'var(--text-primary)';
      
      item.innerHTML = `
        <div class="item-info">
          <div>${invite.code}</div>
          <div style="font-size: 10px; color: ${statusColor};">${status}</div>
        </div>
        <div class="item-actions">
          ${!invite.used ? `<button class="terminal-btn small" onclick="admin.revokeInvite('${invite.code}')">revoke</button>` : ''}
        </div>
      `;
      invitesList.appendChild(item);
    });
  }

  async loadStats() {
    const stats = await adminModule.getStats();
    const statsContent = document.getElementById('statsContent');
    
    statsContent.innerHTML = `
      <div class="stat-item">
        <div class="stat-label">Total Users</div>
        <div class="stat-value">${stats.totalUsers}</div>
      </div>
      <div class="stat-item">
        <div class="stat-label">Active Invites</div>
        <div class="stat-value">${stats.activeInvites}</div>
      </div>
      <div class="stat-item">
        <div class="stat-label">Used Invites</div>
        <div class="stat-value">${stats.usedInvites}</div>
      </div>
      <div class="stat-item">
        <div class="stat-label">Admins</div>
        <div class="stat-value">${stats.totalAdmins}</div>
      </div>
    `;
  }

  async showAddContact() {
    const pubKey = prompt('Enter contact public key:');
    if (!pubKey) return;
    
    const alias = prompt('Enter contact alias (optional):') || '';
    
    try {
      await gunModule.addContact(pubKey, { alias });
      this.loadContacts();
    } catch (error) {
      alert(`Error: ${error.message}`);
    }
  }

  logout() {
    authModule.logout();
  }
}

// Admin helper object
window.admin = {
  async generateInvite() {
    const invite = await adminModule.generateInvite();
    alert(`Invite generated: ${invite.code}`);
    app.refreshInvites();
  },
  
  async revokeInvite(code) {
    if (confirm(`Revoke invite ${code}?`)) {
      await adminModule.revokeInvite(code);
      app.refreshInvites();
    }
  },
  
  async banUser(pubKey) {
    const reason = prompt('Ban reason:');
    if (reason !== null) {
      await adminModule.banUser(pubKey, reason);
      app.refreshUsers();
    }
  },
  
  refreshUsers: () => app.refreshUsers(),
  refreshInvites: () => app.refreshInvites()
};

// Initialize app
const app = new WhisperzApp();
window.app = app;