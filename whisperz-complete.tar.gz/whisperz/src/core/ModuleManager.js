/**
 * ModuleManager - Core module system for Whisperz
 * Handles module registration, initialization, and inter-module communication
 */

import EventEmitter from 'eventemitter3';

class ModuleManager extends EventEmitter {
  constructor() {
    super();
    this.modules = new Map();
    this.moduleStates = new Map();
    this.dependencies = new Map();
    this.config = {};
  }

  /**
   * Register a module with the manager
   * @param {string} name - Module name
   * @param {Object} module - Module instance or class
   * @param {Array} dependencies - Array of module names this module depends on
   */
  async register(name, module, dependencies = []) {
    if (this.modules.has(name)) {
      console.warn(`Module ${name} is already registered`);
      return;
    }

    this.modules.set(name, module);
    this.dependencies.set(name, dependencies);
    this.moduleStates.set(name, 'registered');
    
    this.emit('module:registered', { name, module });
    console.log(`Module registered: ${name}`);
  }

  /**
   * Initialize a specific module
   * @param {string} name - Module name to initialize
   */
  async initializeModule(name) {
    const module = this.modules.get(name);
    if (!module) {
      throw new Error(`Module ${name} not found`);
    }

    const state = this.moduleStates.get(name);
    if (state === 'initialized' || state === 'initializing') {
      return module;
    }

    // Check and initialize dependencies first
    const deps = this.dependencies.get(name) || [];
    for (const dep of deps) {
      if (!this.modules.has(dep)) {
        throw new Error(`Dependency ${dep} for module ${name} not found`);
      }
      await this.initializeModule(dep);
    }

    this.moduleStates.set(name, 'initializing');
    
    try {
      // If module has an init method, call it
      if (typeof module.init === 'function') {
        await module.init(this);
      }
      
      this.moduleStates.set(name, 'initialized');
      this.emit('module:initialized', { name, module });
      console.log(`Module initialized: ${name}`);
      
      return module;
    } catch (error) {
      this.moduleStates.set(name, 'failed');
      this.emit('module:error', { name, error });
      throw new Error(`Failed to initialize module ${name}: ${error.message}`);
    }
  }

  /**
   * Initialize all registered modules
   */
  async initializeAll() {
    const moduleNames = Array.from(this.modules.keys());
    
    for (const name of moduleNames) {
      try {
        await this.initializeModule(name);
      } catch (error) {
        console.error(`Failed to initialize module ${name}:`, error);
      }
    }
  }

  /**
   * Get a module by name
   * @param {string} name - Module name
   * @returns {Object} Module instance
   */
  getModule(name) {
    const module = this.modules.get(name);
    if (!module) {
      throw new Error(`Module ${name} not found`);
    }
    
    const state = this.moduleStates.get(name);
    if (state !== 'initialized') {
      console.warn(`Module ${name} is not initialized yet (state: ${state})`);
    }
    
    return module;
  }

  /**
   * Check if a module is registered
   * @param {string} name - Module name
   * @returns {boolean}
   */
  hasModule(name) {
    return this.modules.has(name);
  }

  /**
   * Get module state
   * @param {string} name - Module name
   * @returns {string} Module state
   */
  getModuleState(name) {
    return this.moduleStates.get(name);
  }

  /**
   * Unload a module
   * @param {string} name - Module name
   */
  async unloadModule(name) {
    const module = this.modules.get(name);
    if (!module) {
      return;
    }

    // Check if other modules depend on this one
    for (const [modName, deps] of this.dependencies) {
      if (deps.includes(name) && this.moduleStates.get(modName) === 'initialized') {
        throw new Error(`Cannot unload ${name}: ${modName} depends on it`);
      }
    }

    // Call cleanup if available
    if (typeof module.cleanup === 'function') {
      await module.cleanup();
    }

    this.modules.delete(name);
    this.moduleStates.delete(name);
    this.dependencies.delete(name);
    
    this.emit('module:unloaded', { name });
    console.log(`Module unloaded: ${name}`);
  }

  /**
   * Set global configuration
   * @param {Object} config - Configuration object
   */
  setConfig(config) {
    this.config = { ...this.config, ...config };
    this.emit('config:updated', this.config);
  }

  /**
   * Get configuration
   * @returns {Object} Configuration object
   */
  getConfig() {
    return this.config;
  }

  /**
   * List all modules and their states
   * @returns {Array} Array of module info
   */
  listModules() {
    const moduleList = [];
    for (const [name, module] of this.modules) {
      moduleList.push({
        name,
        state: this.moduleStates.get(name),
        dependencies: this.dependencies.get(name) || [],
        hasInit: typeof module.init === 'function',
        hasCleanup: typeof module.cleanup === 'function'
      });
    }
    return moduleList;
  }
}

// Create singleton instance
const moduleManager = new ModuleManager();

export default moduleManager;