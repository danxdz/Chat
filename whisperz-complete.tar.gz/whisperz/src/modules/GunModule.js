/**
 * GunModule - Gun.js integration for decentralized data management
 * Handles user authentication, data persistence, and peer synchronization
 */

import Gun from 'gun/gun';
import 'gun/sea'; // Security, Encryption, Authorization
import 'gun/axe'; // For debugging
import EventEmitter from 'eventemitter3';

class GunModule extends EventEmitter {
  constructor() {
    super();
    this.gun = null;
    this.user = null;
    this.peers = [];
    this.isAuthenticated = false;
    this.userData = null;
  }

  /**
   * Initialize Gun.js with peer configuration
   * @param {Object} moduleManager - Reference to module manager
   */
  async init(moduleManager) {
    this.moduleManager = moduleManager;
    const config = moduleManager.getConfig();
    
    // Initialize Gun with peers
    const peers = config.gunPeers || [
      'https://gun-manhattan.herokuapp.com/gun',
      'https://gun-matrix.herokuapp.com/gun',
      'https://gun.dirtbag.dev/gun',
      'https://gundb-relay-mlccl.ondigitalocean.app/gun'
    ];

    this.gun = Gun({
      peers: peers,
      localStorage: true,
      radisk: true,
      WebRTC: { iceServers: config.iceServers },
      axe: false // Set to true for debugging
    });

    this.user = this.gun.user();
    
    // Set up authentication listeners
    this.setupAuthListeners();
    
    console.log('Gun.js initialized with peers:', peers);
    this.emit('gun:initialized', { peers });
  }

  /**
   * Set up authentication event listeners
   */
  setupAuthListeners() {
    this.gun.on('auth', () => {
      this.isAuthenticated = true;
      this.emit('auth:success');
      console.log('User authenticated');
      this.loadUserData();
    });

    this.gun.on('auth-fail', (error) => {
      this.isAuthenticated = false;
      this.emit('auth:failed', error);
      console.error('Authentication failed:', error);
    });
  }

  /**
   * Create a new user account
   * @param {string} username - Username
   * @param {string} password - Password
   * @returns {Promise} Resolution of user creation
   */
  async createUser(username, password) {
    return new Promise((resolve, reject) => {
      this.user.create(username, password, (ack) => {
        if (ack.err) {
          this.emit('user:create:failed', ack.err);
          reject(new Error(ack.err));
        } else {
          this.emit('user:created', { username });
          console.log('User created:', username);
          // Auto-login after creation
          this.login(username, password).then(resolve).catch(reject);
        }
      });
    });
  }

  /**
   * Login with existing credentials
   * @param {string} username - Username
   * @param {string} password - Password
   * @returns {Promise} Resolution of login
   */
  async login(username, password) {
    return new Promise((resolve, reject) => {
      this.user.auth(username, password, (ack) => {
        if (ack.err) {
          this.emit('auth:failed', ack.err);
          reject(new Error(ack.err));
        } else {
          this.isAuthenticated = true;
          this.userData = ack;
          this.emit('auth:success', { username, pub: ack.sea.pub });
          resolve(ack);
        }
      });
    });
  }

  /**
   * Logout current user
   */
  logout() {
    this.user.leave();
    this.isAuthenticated = false;
    this.userData = null;
    this.emit('auth:logout');
    console.log('User logged out');
  }

  /**
   * Load user data after authentication
   */
  loadUserData() {
    if (!this.isAuthenticated) return;

    // Load user profile
    this.user.get('profile').on((data) => {
      this.emit('user:profile:updated', data);
    });

    // Load user contacts
    this.user.get('contacts').map().on((contact, id) => {
      this.emit('user:contact:updated', { id, contact });
    });

    // Load user chats
    this.user.get('chats').map().on((chat, id) => {
      this.emit('user:chat:updated', { id, chat });
    });
  }

  /**
   * Update user profile
   * @param {Object} profile - Profile data
   */
  async updateProfile(profile) {
    if (!this.isAuthenticated) {
      throw new Error('User not authenticated');
    }

    await this.user.get('profile').put(profile);
    this.emit('user:profile:saved', profile);
  }

  /**
   * Get user's public key
   * @returns {string} Public key
   */
  getPublicKey() {
    if (!this.isAuthenticated || !this.userData) {
      return null;
    }
    return this.userData.sea.pub;
  }

  /**
   * Add a contact
   * @param {string} publicKey - Contact's public key
   * @param {Object} contactInfo - Contact information
   */
  async addContact(publicKey, contactInfo) {
    if (!this.isAuthenticated) {
      throw new Error('User not authenticated');
    }

    const contact = {
      ...contactInfo,
      publicKey,
      addedAt: Date.now()
    };

    await this.user.get('contacts').get(publicKey).put(contact);
    this.emit('contact:added', contact);
  }

  /**
   * Remove a contact
   * @param {string} publicKey - Contact's public key
   */
  async removeContact(publicKey) {
    if (!this.isAuthenticated) {
      throw new Error('User not authenticated');
    }

    await this.user.get('contacts').get(publicKey).put(null);
    this.emit('contact:removed', publicKey);
  }

  /**
   * Get all contacts
   * @returns {Promise<Object>} Contacts object
   */
  async getContacts() {
    if (!this.isAuthenticated) {
      throw new Error('User not authenticated');
    }

    return new Promise((resolve) => {
      const contacts = {};
      this.user.get('contacts').map().once((contact, id) => {
        if (contact) {
          contacts[id] = contact;
        }
      });
      setTimeout(() => resolve(contacts), 500); // Wait for data to load
    });
  }

  /**
   * Create or get a chat room
   * @param {string} roomId - Room identifier
   * @returns {Object} Chat room reference
   */
  getChatRoom(roomId) {
    return this.gun.get('chats').get(roomId);
  }

  /**
   * Send a message to a chat room
   * @param {string} roomId - Room identifier
   * @param {Object} message - Message object
   */
  async sendMessage(roomId, message) {
    if (!this.isAuthenticated) {
      throw new Error('User not authenticated');
    }

    const messageData = {
      ...message,
      from: this.getPublicKey(),
      timestamp: Date.now(),
      id: Gun.node.Soul.uuid()
    };

    // Save to chat room
    await this.getChatRoom(roomId).get('messages').get(messageData.id).put(messageData);
    
    // Save reference in user's chats
    await this.user.get('chats').get(roomId).get('messages').get(messageData.id).put(true);
    
    this.emit('message:sent', { roomId, message: messageData });
    return messageData;
  }

  /**
   * Subscribe to messages in a chat room
   * @param {string} roomId - Room identifier
   * @param {Function} callback - Callback for new messages
   */
  subscribeToRoom(roomId, callback) {
    const room = this.getChatRoom(roomId);
    
    room.get('messages').map().on((message, id) => {
      if (message && typeof message === 'object') {
        callback({ ...message, id });
        this.emit('message:received', { roomId, message: { ...message, id } });
      }
    });

    // Also subscribe to typing indicators
    room.get('typing').on((data) => {
      this.emit('room:typing', { roomId, data });
    });
  }

  /**
   * Set typing indicator
   * @param {string} roomId - Room identifier
   * @param {boolean} isTyping - Typing state
   */
  async setTyping(roomId, isTyping) {
    if (!this.isAuthenticated) return;

    const typingData = {
      user: this.getPublicKey(),
      isTyping,
      timestamp: Date.now()
    };

    await this.getChatRoom(roomId).get('typing').get(this.getPublicKey()).put(typingData);
  }

  /**
   * Get Gun instance for direct access
   * @returns {Object} Gun instance
   */
  getGun() {
    return this.gun;
  }

  /**
   * Get User instance for direct access
   * @returns {Object} User instance
   */
  getUser() {
    return this.user;
  }

  /**
   * Clean up module
   */
  async cleanup() {
    if (this.isAuthenticated) {
      this.logout();
    }
    
    // Close Gun connections
    if (this.gun) {
      this.gun.off();
    }
    
    this.removeAllListeners();
    console.log('Gun module cleaned up');
  }
}

export default new GunModule();