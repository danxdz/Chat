/**
 * WebRTCModule - WebRTC integration for secure P2P messaging
 * Handles peer connections, signaling, and encrypted communication
 */

import SimplePeer from 'simple-peer';
import EventEmitter from 'eventemitter3';
import { v4 as uuidv4 } from 'uuid';

class WebRTCModule extends EventEmitter {
  constructor() {
    super();
    this.peers = new Map();
    this.pendingOffers = new Map();
    this.gunModule = null;
    this.moduleManager = null;
    this.iceServers = [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' }
    ];
  }

  /**
   * Initialize WebRTC module
   * @param {Object} moduleManager - Reference to module manager
   */
  async init(moduleManager) {
    this.moduleManager = moduleManager;
    this.gunModule = moduleManager.getModule('gun');
    
    const config = moduleManager.getConfig();
    if (config.iceServers) {
      this.iceServers = config.iceServers;
    }

    // Listen for Gun.js signaling messages
    this.setupSignaling();
    
    console.log('WebRTC module initialized');
    this.emit('webrtc:initialized');
  }

  /**
   * Set up signaling through Gun.js
   */
  setupSignaling() {
    if (!this.gunModule || !this.gunModule.isAuthenticated) {
      console.warn('Gun module not authenticated, skipping signaling setup');
      return;
    }

    const user = this.gunModule.getUser();
    const myPubKey = this.gunModule.getPublicKey();

    // Listen for incoming signals
    user.get('signals').map().on((signal, id) => {
      if (signal && signal.from !== myPubKey) {
        this.handleSignal(signal);
      }
    });

    console.log('WebRTC signaling set up');
  }

  /**
   * Create a peer connection
   * @param {string} targetPubKey - Target peer's public key
   * @param {boolean} initiator - Whether this peer initiates the connection
   * @returns {SimplePeer} Peer instance
   */
  createPeer(targetPubKey, initiator = true) {
    // Check if peer already exists
    if (this.peers.has(targetPubKey)) {
      console.log('Peer already exists:', targetPubKey);
      return this.peers.get(targetPubKey);
    }

    const peer = new SimplePeer({
      initiator,
      trickle: false,
      config: {
        iceServers: this.iceServers
      }
    });

    // Store peer
    this.peers.set(targetPubKey, peer);

    // Set up peer event handlers
    this.setupPeerHandlers(peer, targetPubKey);

    console.log(`Peer created for ${targetPubKey} (initiator: ${initiator})`);
    return peer;
  }

  /**
   * Set up event handlers for a peer
   * @param {SimplePeer} peer - Peer instance
   * @param {string} targetPubKey - Target peer's public key
   */
  setupPeerHandlers(peer, targetPubKey) {
    // When peer generates signaling data
    peer.on('signal', (data) => {
      this.sendSignal(targetPubKey, data);
    });

    // When peer connection is established
    peer.on('connect', () => {
      console.log(`Connected to peer: ${targetPubKey}`);
      this.emit('peer:connected', { pubKey: targetPubKey, peer });
      
      // Send a test message
      peer.send(JSON.stringify({
        type: 'connection',
        message: 'Connected successfully',
        timestamp: Date.now()
      }));
    });

    // When receiving data from peer
    peer.on('data', (data) => {
      try {
        const message = JSON.parse(data.toString());
        this.handlePeerMessage(targetPubKey, message);
      } catch (error) {
        console.error('Error parsing peer message:', error);
      }
    });

    // Handle errors
    peer.on('error', (error) => {
      console.error(`Peer error with ${targetPubKey}:`, error);
      this.emit('peer:error', { pubKey: targetPubKey, error });
      this.removePeer(targetPubKey);
    });

    // Handle peer close
    peer.on('close', () => {
      console.log(`Peer closed: ${targetPubKey}`);
      this.emit('peer:closed', { pubKey: targetPubKey });
      this.removePeer(targetPubKey);
    });

    // Handle streams (for future video/audio support)
    peer.on('stream', (stream) => {
      this.emit('peer:stream', { pubKey: targetPubKey, stream });
    });
  }

  /**
   * Send signaling data through Gun.js
   * @param {string} targetPubKey - Target peer's public key
   * @param {Object} signalData - Signaling data
   */
  async sendSignal(targetPubKey, signalData) {
    if (!this.gunModule || !this.gunModule.isAuthenticated) {
      console.error('Cannot send signal: not authenticated');
      return;
    }

    const myPubKey = this.gunModule.getPublicKey();
    const signal = {
      from: myPubKey,
      to: targetPubKey,
      data: signalData,
      timestamp: Date.now(),
      id: uuidv4()
    };

    // Send to target's signal inbox
    const gun = this.gunModule.getGun();
    await gun.user(targetPubKey).get('signals').get(signal.id).put(signal);
    
    console.log(`Signal sent to ${targetPubKey}`);
    this.emit('signal:sent', signal);
  }

  /**
   * Handle incoming signaling data
   * @param {Object} signal - Signal object
   */
  handleSignal(signal) {
    const { from, data } = signal;
    
    // Check if this signal is for us
    if (signal.to !== this.gunModule.getPublicKey()) {
      return;
    }

    console.log(`Received signal from ${from}`);
    
    // Get or create peer
    let peer = this.peers.get(from);
    
    if (!peer) {
      // Create non-initiator peer
      peer = this.createPeer(from, false);
    }

    // Signal the peer
    try {
      peer.signal(data);
      this.emit('signal:processed', signal);
    } catch (error) {
      console.error('Error processing signal:', error);
    }
  }

  /**
   * Handle messages from peers
   * @param {string} fromPubKey - Sender's public key
   * @param {Object} message - Message object
   */
  handlePeerMessage(fromPubKey, message) {
    console.log(`Message from ${fromPubKey}:`, message);
    
    switch (message.type) {
      case 'chat':
        this.emit('message:received', {
          from: fromPubKey,
          content: message.content,
          timestamp: message.timestamp
        });
        break;
        
      case 'file':
        this.emit('file:received', {
          from: fromPubKey,
          file: message.file,
          metadata: message.metadata
        });
        break;
        
      case 'typing':
        this.emit('peer:typing', {
          from: fromPubKey,
          isTyping: message.isTyping
        });
        break;
        
      case 'connection':
        console.log(`Connection message from ${fromPubKey}: ${message.message}`);
        break;
        
      default:
        this.emit('message:custom', {
          from: fromPubKey,
          message
        });
    }
  }

  /**
   * Send a message to a peer
   * @param {string} targetPubKey - Target peer's public key
   * @param {Object} message - Message to send
   */
  sendToPeer(targetPubKey, message) {
    const peer = this.peers.get(targetPubKey);
    
    if (!peer) {
      console.error(`No peer connection with ${targetPubKey}`);
      this.emit('send:error', { target: targetPubKey, error: 'No peer connection' });
      return false;
    }

    if (!peer.connected) {
      console.error(`Peer ${targetPubKey} not connected`);
      this.emit('send:error', { target: targetPubKey, error: 'Peer not connected' });
      return false;
    }

    try {
      peer.send(JSON.stringify(message));
      this.emit('message:sent', { to: targetPubKey, message });
      return true;
    } catch (error) {
      console.error(`Error sending to ${targetPubKey}:`, error);
      this.emit('send:error', { target: targetPubKey, error });
      return false;
    }
  }

  /**
   * Send a chat message
   * @param {string} targetPubKey - Target peer's public key
   * @param {string} content - Message content
   */
  sendChatMessage(targetPubKey, content) {
    return this.sendToPeer(targetPubKey, {
      type: 'chat',
      content,
      timestamp: Date.now()
    });
  }

  /**
   * Send typing indicator
   * @param {string} targetPubKey - Target peer's public key
   * @param {boolean} isTyping - Typing state
   */
  sendTypingIndicator(targetPubKey, isTyping) {
    return this.sendToPeer(targetPubKey, {
      type: 'typing',
      isTyping,
      timestamp: Date.now()
    });
  }

  /**
   * Send a file
   * @param {string} targetPubKey - Target peer's public key
   * @param {ArrayBuffer} file - File data
   * @param {Object} metadata - File metadata
   */
  sendFile(targetPubKey, file, metadata) {
    return this.sendToPeer(targetPubKey, {
      type: 'file',
      file,
      metadata,
      timestamp: Date.now()
    });
  }

  /**
   * Connect to a peer
   * @param {string} targetPubKey - Target peer's public key
   */
  connectToPeer(targetPubKey) {
    if (this.peers.has(targetPubKey)) {
      console.log(`Already connected/connecting to ${targetPubKey}`);
      return this.peers.get(targetPubKey);
    }

    const peer = this.createPeer(targetPubKey, true);
    return peer;
  }

  /**
   * Disconnect from a peer
   * @param {string} targetPubKey - Target peer's public key
   */
  disconnectFromPeer(targetPubKey) {
    const peer = this.peers.get(targetPubKey);
    
    if (peer) {
      peer.destroy();
      this.removePeer(targetPubKey);
      console.log(`Disconnected from ${targetPubKey}`);
    }
  }

  /**
   * Remove a peer from the peers map
   * @param {string} pubKey - Peer's public key
   */
  removePeer(pubKey) {
    this.peers.delete(pubKey);
  }

  /**
   * Get connected peers
   * @returns {Array} Array of connected peer public keys
   */
  getConnectedPeers() {
    const connected = [];
    for (const [pubKey, peer] of this.peers) {
      if (peer.connected) {
        connected.push(pubKey);
      }
    }
    return connected;
  }

  /**
   * Check if connected to a peer
   * @param {string} pubKey - Peer's public key
   * @returns {boolean} Connection status
   */
  isConnected(pubKey) {
    const peer = this.peers.get(pubKey);
    return peer ? peer.connected : false;
  }

  /**
   * Get peer statistics
   * @param {string} pubKey - Peer's public key
   * @returns {Object} Peer statistics
   */
  getPeerStats(pubKey) {
    const peer = this.peers.get(pubKey);
    if (!peer) return null;

    return {
      connected: peer.connected,
      initiator: peer.initiator,
      channelName: peer.channelName,
      remoteAddress: peer.remoteAddress,
      remotePort: peer.remotePort,
      localAddress: peer.localAddress,
      localPort: peer.localPort
    };
  }

  /**
   * Clean up module
   */
  async cleanup() {
    // Destroy all peer connections
    for (const [pubKey, peer] of this.peers) {
      peer.destroy();
    }
    
    this.peers.clear();
    this.pendingOffers.clear();
    this.removeAllListeners();
    
    console.log('WebRTC module cleaned up');
  }
}

export default new WebRTCModule();