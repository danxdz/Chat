/**
 * AdminModule - Administrative functions for user and invite management
 * Clean CRUD operations with minimal interface
 */

import EventEmitter from 'eventemitter3';
import { v4 as uuidv4 } from 'uuid';

class AdminModule extends EventEmitter {
  constructor() {
    super();
    this.gunModule = null;
    this.authModule = null;
  }

  async init(moduleManager) {
    this.moduleManager = moduleManager;
    this.gunModule = moduleManager.getModule('gun');
    this.authModule = moduleManager.getModule('auth');
    
    console.log('[ADMIN] Module initialized');
  }

  /**
   * Check if current user is admin
   */
  isAdmin() {
    return this.authModule && this.authModule.isAdmin;
  }

  /**
   * Generate invite code
   */
  async generateInvite(options = {}) {
    if (!this.isAdmin()) {
      throw new Error('Admin access required');
    }

    const code = options.customCode || this.generateCode();
    const invite = {
      code,
      created: Date.now(),
      createdBy: this.gunModule.getPublicKey(),
      expires: options.expires || Date.now() + (7 * 24 * 60 * 60 * 1000), // 7 days default
      maxUses: options.maxUses || 1,
      used: false,
      note: options.note || ''
    };

    const gun = this.gunModule.getGun();
    await gun.get('invites').get(code).put(invite);
    
    console.log(`[ADMIN] Invite generated: ${code}`);
    this.emit('invite:created', invite);
    
    return invite;
  }

  /**
   * Generate random invite code
   */
  generateCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 8; i++) {
      if (i === 4) code += '-';
      code += chars[Math.floor(Math.random() * chars.length)];
    }
    return code;
  }

  /**
   * List all invites
   */
  async listInvites() {
    if (!this.isAdmin()) {
      throw new Error('Admin access required');
    }

    const gun = this.gunModule.getGun();
    const invites = [];
    
    return new Promise((resolve) => {
      gun.get('invites').map().once((invite, code) => {
        if (invite) {
          invites.push({ ...invite, code });
        }
      });
      
      setTimeout(() => {
        invites.sort((a, b) => b.created - a.created);
        resolve(invites);
      }, 500);
    });
  }

  /**
   * Revoke invite
   */
  async revokeInvite(code) {
    if (!this.isAdmin()) {
      throw new Error('Admin access required');
    }

    const gun = this.gunModule.getGun();
    await gun.get('invites').get(code).put(null);
    
    console.log(`[ADMIN] Invite revoked: ${code}`);
    this.emit('invite:revoked', code);
  }

  /**
   * List all users
   */
  async listUsers() {
    if (!this.isAdmin()) {
      throw new Error('Admin access required');
    }

    const gun = this.gunModule.getGun();
    const users = [];
    
    return new Promise((resolve) => {
      gun.get('~@').map().once((alias, pub) => {
        if (alias) {
          users.push({ 
            pub: pub.slice(1), // Remove ~ prefix
            alias,
            isOnline: false // Will be updated by presence system
          });
        }
      });
      
      setTimeout(() => {
        resolve(users);
      }, 1000);
    });
  }

  /**
   * Get user details
   */
  async getUserDetails(pubKey) {
    if (!this.isAdmin()) {
      throw new Error('Admin access required');
    }

    const gun = this.gunModule.getGun();
    
    return new Promise((resolve) => {
      const details = {
        pub: pubKey,
        profile: null,
        contacts: [],
        lastSeen: null
      };

      // Get user profile
      gun.user(pubKey).get('profile').once((profile) => {
        details.profile = profile;
      });

      // Get user contacts
      gun.user(pubKey).get('contacts').map().once((contact, id) => {
        if (contact) {
          details.contacts.push({ ...contact, id });
        }
      });

      // Get last seen
      gun.user(pubKey).get('presence').once((presence) => {
        if (presence) {
          details.lastSeen = presence.lastSeen;
        }
      });

      setTimeout(() => resolve(details), 500);
    });
  }

  /**
   * Ban user
   */
  async banUser(pubKey, reason = '') {
    if (!this.isAdmin()) {
      throw new Error('Admin access required');
    }

    const gun = this.gunModule.getGun();
    const ban = {
      pubKey,
      reason,
      bannedAt: Date.now(),
      bannedBy: this.gunModule.getPublicKey()
    };

    await gun.get('banned').get(pubKey).put(ban);
    
    console.log(`[ADMIN] User banned: ${pubKey}`);
    this.emit('user:banned', ban);
    
    return ban;
  }

  /**
   * Unban user
   */
  async unbanUser(pubKey) {
    if (!this.isAdmin()) {
      throw new Error('Admin access required');
    }

    const gun = this.gunModule.getGun();
    await gun.get('banned').get(pubKey).put(null);
    
    console.log(`[ADMIN] User unbanned: ${pubKey}`);
    this.emit('user:unbanned', pubKey);
  }

  /**
   * Check if user is banned
   */
  async isUserBanned(pubKey) {
    const gun = this.gunModule.getGun();
    
    return new Promise((resolve) => {
      gun.get('banned').get(pubKey).once((ban) => {
        resolve(!!ban);
      });
    });
  }

  /**
   * Add admin
   */
  async addAdmin(pubKey) {
    if (!this.isAdmin()) {
      throw new Error('Admin access required');
    }

    const gun = this.gunModule.getGun();
    await gun.get('admins').get(pubKey).put(true);
    
    console.log(`[ADMIN] Admin added: ${pubKey}`);
    this.emit('admin:added', pubKey);
  }

  /**
   * Remove admin
   */
  async removeAdmin(pubKey) {
    if (!this.isAdmin()) {
      throw new Error('Admin access required');
    }

    // Prevent removing self
    if (pubKey === this.gunModule.getPublicKey()) {
      throw new Error('Cannot remove yourself as admin');
    }

    const gun = this.gunModule.getGun();
    await gun.get('admins').get(pubKey).put(null);
    
    console.log(`[ADMIN] Admin removed: ${pubKey}`);
    this.emit('admin:removed', pubKey);
  }

  /**
   * List all admins
   */
  async listAdmins() {
    if (!this.isAdmin()) {
      throw new Error('Admin access required');
    }

    const gun = this.gunModule.getGun();
    const admins = [];
    
    return new Promise((resolve) => {
      gun.get('admins').map().once((isAdmin, pubKey) => {
        if (isAdmin) {
          admins.push(pubKey);
        }
      });
      
      setTimeout(() => resolve(admins), 500);
    });
  }

  /**
   * Get system stats
   */
  async getStats() {
    if (!this.isAdmin()) {
      throw new Error('Admin access required');
    }

    const [users, invites, admins] = await Promise.all([
      this.listUsers(),
      this.listInvites(),
      this.listAdmins()
    ]);

    return {
      totalUsers: users.length,
      totalInvites: invites.length,
      activeInvites: invites.filter(i => !i.used && (!i.expires || i.expires > Date.now())).length,
      usedInvites: invites.filter(i => i.used).length,
      totalAdmins: admins.length,
      timestamp: Date.now()
    };
  }

  /**
   * Create friendship between users
   */
  async createFriendship(user1PubKey, user2PubKey) {
    if (!this.isAdmin()) {
      throw new Error('Admin access required');
    }

    const gun = this.gunModule.getGun();
    const friendshipId = `${user1PubKey}-${user2PubKey}`;
    
    const friendship = {
      users: [user1PubKey, user2PubKey],
      created: Date.now(),
      createdBy: this.gunModule.getPublicKey()
    };

    // Add to both users' contacts
    await gun.user(user1PubKey).get('contacts').get(user2PubKey).put({
      pubKey: user2PubKey,
      addedAt: Date.now(),
      addedBy: 'admin'
    });

    await gun.user(user2PubKey).get('contacts').get(user1PubKey).put({
      pubKey: user1PubKey,
      addedAt: Date.now(),
      addedBy: 'admin'
    });

    // Store friendship record
    await gun.get('friendships').get(friendshipId).put(friendship);
    
    console.log(`[ADMIN] Friendship created: ${friendshipId}`);
    this.emit('friendship:created', friendship);
    
    return friendship;
  }

  /**
   * Remove friendship
   */
  async removeFriendship(user1PubKey, user2PubKey) {
    if (!this.isAdmin()) {
      throw new Error('Admin access required');
    }

    const gun = this.gunModule.getGun();
    
    // Remove from both users' contacts
    await gun.user(user1PubKey).get('contacts').get(user2PubKey).put(null);
    await gun.user(user2PubKey).get('contacts').get(user1PubKey).put(null);
    
    // Remove friendship record
    const friendshipId = `${user1PubKey}-${user2PubKey}`;
    await gun.get('friendships').get(friendshipId).put(null);
    
    console.log(`[ADMIN] Friendship removed: ${friendshipId}`);
    this.emit('friendship:removed', friendshipId);
  }

  async cleanup() {
    this.removeAllListeners();
  }
}

export default new AdminModule();