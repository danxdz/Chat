/**
 * AuthModule - Authentication with invite-only registration
 * Clean, secure authentication system
 */

import EventEmitter from 'eventemitter3';
import { v4 as uuidv4 } from 'uuid';

class AuthModule extends EventEmitter {
  constructor() {
    super();
    this.currentUser = null;
    this.gunModule = null;
    this.inviteModule = null;
    this.isAdmin = false;
  }

  async init(moduleManager) {
    this.moduleManager = moduleManager;
    this.gunModule = moduleManager.getModule('gun');
    
    // Check for stored session
    this.checkStoredSession();
    
    console.log('[AUTH] Module initialized');
  }

  /**
   * Check for stored session
   */
  checkStoredSession() {
    const stored = localStorage.getItem('whisperz_session');
    if (stored) {
      try {
        const session = JSON.parse(stored);
        if (session.expires > Date.now()) {
          this.currentUser = session.user;
          this.emit('auth:restored', session.user);
        } else {
          localStorage.removeItem('whisperz_session');
        }
      } catch (e) {
        localStorage.removeItem('whisperz_session');
      }
    }
  }

  /**
   * Login with credentials
   */
  async login(username, password) {
    try {
      const result = await this.gunModule.login(username, password);
      
      // Check if user is admin
      await this.checkAdminStatus();
      
      this.currentUser = {
        username,
        pub: result.sea.pub,
        epub: result.sea.epub,
        alias: username
      };

      // Store session
      const session = {
        user: this.currentUser,
        expires: Date.now() + (24 * 60 * 60 * 1000) // 24 hours
      };
      localStorage.setItem('whisperz_session', JSON.stringify(session));

      this.emit('auth:success', this.currentUser);
      console.log(`[AUTH] User logged in: ${username}`);
      
      return { success: true, user: this.currentUser };
    } catch (error) {
      this.emit('auth:failed', error.message);
      return { success: false, error: error.message };
    }
  }

  /**
   * Register with invite code
   */
  async registerWithInvite(username, password, inviteCode) {
    try {
      // Validate invite code
      const inviteValid = await this.validateInvite(inviteCode);
      if (!inviteValid) {
        throw new Error('Invalid or expired invite code');
      }

      // Create user
      await this.gunModule.createUser(username, password);
      
      // Mark invite as used
      await this.consumeInvite(inviteCode, username);
      
      // Auto-login
      return await this.login(username, password);
    } catch (error) {
      this.emit('register:failed', error.message);
      return { success: false, error: error.message };
    }
  }

  /**
   * Validate invite code
   */
  async validateInvite(code) {
    const gun = this.gunModule.getGun();
    
    return new Promise((resolve) => {
      gun.get('invites').get(code).once((invite) => {
        if (!invite) {
          resolve(false);
        } else if (invite.used) {
          resolve(false);
        } else if (invite.expires && invite.expires < Date.now()) {
          resolve(false);
        } else {
          resolve(true);
        }
      });
    });
  }

  /**
   * Consume invite code
   */
  async consumeInvite(code, username) {
    const gun = this.gunModule.getGun();
    await gun.get('invites').get(code).put({
      used: true,
      usedBy: username,
      usedAt: Date.now()
    });
  }

  /**
   * Check if current user is admin
   */
  async checkAdminStatus() {
    if (!this.gunModule.isAuthenticated) return false;
    
    const gun = this.gunModule.getGun();
    const user = this.gunModule.getUser();
    const pub = this.gunModule.getPublicKey();
    
    return new Promise((resolve) => {
      gun.get('admins').get(pub).once((isAdmin) => {
        this.isAdmin = !!isAdmin;
        if (this.isAdmin) {
          this.emit('admin:verified');
          console.log('[AUTH] Admin status verified');
        }
        resolve(this.isAdmin);
      });
    });
  }

  /**
   * Logout
   */
  logout() {
    this.gunModule.logout();
    this.currentUser = null;
    this.isAdmin = false;
    localStorage.removeItem('whisperz_session');
    this.emit('auth:logout');
    console.log('[AUTH] User logged out');
  }

  /**
   * Get current user
   */
  getCurrentUser() {
    return this.currentUser;
  }

  /**
   * Check if authenticated
   */
  isAuthenticated() {
    return !!this.currentUser && this.gunModule.isAuthenticated;
  }

  async cleanup() {
    this.logout();
    this.removeAllListeners();
  }
}

export default new AuthModule();